# 图片提示词已整合到 services/image_service.py 中
# 这里保留空文件作为模块标识
