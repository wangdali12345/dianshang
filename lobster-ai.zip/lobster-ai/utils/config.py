import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    SERVICE_NAME = "lobster-ai"
    VERSION = "1.0.0"
    HOST = os.getenv("HOST", "0.0.0.0")
    PORT = int(os.getenv("PORT", "8000"))

    TEXT_PROVIDER = os.getenv("TEXT_PROVIDER", "zhipu")
    IMAGE_PROVIDER = os.getenv("IMAGE_PROVIDER", "zhipu")

    ZHIPU_API_KEY = os.getenv("ZHIPU_API_KEY", "")
    MINIMAX_API_KEY = os.getenv("MINIMAX_API_KEY", "")
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
    ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")

    @classmethod
    def get_text_api_key(cls) -> str:
        if cls.TEXT_PROVIDER == "zhipu":
            return cls.ZHIPU_API_KEY
        elif cls.TEXT_PROVIDER == "minimax":
            return cls.MINIMAX_API_KEY
        elif cls.TEXT_PROVIDER == "claude":
            return cls.ANTHROPIC_API_KEY
        return ""

    @classmethod
    def get_image_api_key(cls) -> str:
        if cls.IMAGE_PROVIDER == "zhipu":
            return cls.ZHIPU_API_KEY
        elif cls.IMAGE_PROVIDER == "openai":
            return cls.OPENAI_API_KEY
        elif cls.IMAGE_PROVIDER == "minimax":
            return cls.MINIMAX_API_KEY
        return ""
