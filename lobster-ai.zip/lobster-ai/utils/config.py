import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    """配置管理"""

    # 服务信息
    SERVICE_NAME = "lobster-ai"
    VERSION = "1.0.0"
    HOST = os.getenv("HOST", "0.0.0.0")
    PORT = int(os.getenv("PORT", "8000"))

    # AI Provider 选择
    TEXT_PROVIDER = os.getenv("TEXT_PROVIDER", "zhipu")
    IMAGE_PROVIDER = os.getenv("IMAGE_PROVIDER", "zhipu")

    # 智谱 (GLM-4 文本 + CogView 图片)
    ZHIPU_API_KEY = os.getenv("ZHIPU_API_KEY", "")

    # MiniMax
    MINIMAX_API_KEY = os.getenv("MINIMAX_API_KEY", "")

    # OpenAI (DALL-E)
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")

    # Anthropic (Claude)
    ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")

    @classmethod
    def get_text_api_key(cls) -> str:
        """获取文本生成 API Key"""
        if cls.TEXT_PROVIDER == "zhipu":
            return cls.ZHIPU_API_KEY
        elif cls.TEXT_PROVIDER == "minimax":
            return cls.MINIMAX_API_KEY
        elif cls.TEXT_PROVIDER == "claude":
            return cls.ANTHROPIC_API_KEY
        return ""

    @classmethod
    def get_image_api_key(cls) -> str:
        """获取图片生成 API Key"""
        if cls.IMAGE_PROVIDER == "zhipu":
            return cls.ZHIPU_API_KEY
        elif cls.IMAGE_PROVIDER == "openai":
            return cls.OPENAI_API_KEY
        elif cls.IMAGE_PROVIDER == "minimax":
            return cls.MINIMAX_API_KEY
        return ""
