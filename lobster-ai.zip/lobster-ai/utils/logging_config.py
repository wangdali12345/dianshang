import logging
import sys
from pathlib import Path

def setup_logging(log_level: str = "INFO"):
    """配置日志"""
    log_dir = Path("logs")
    log_dir.mkdir(exist_ok=True)

    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(log_dir / "lobster-ai.log", encoding="utf-8")
        ]
    )
    return logging.getLogger("lobster-ai")

# 预配置的logger
logger = setup_logging()
