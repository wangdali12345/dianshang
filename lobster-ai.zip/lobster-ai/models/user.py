from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

class Package(BaseModel):
    """套餐模型"""
    id: str = Field(..., description="套餐ID")
    name: str = Field(..., description="套餐名称")
    price: float = Field(..., description="价格(元)")
    credits: int = Field(..., description="额度/次数")
    description: str = Field("", description="套餐描述")
    features: list = Field(default_factory=list, description="功能列表")

class ShopLinks(BaseModel):
    """店铺链接配置"""
    taobao: str = Field(default="", description="淘宝店铺链接")
    jingdong: str = Field(default="", description="京东店铺链接")
    pinduoduo: str = Field(default="", description="拼多多店铺链接")
    douyin: str = Field(default="", description="抖音小店链接")
    weidian: str = Field(default="", description="微店链接")
    custom: str = Field(default="", description="自定义链接")

class RegisterRequest(BaseModel):
    """注册请求"""
    username: str
    password: str

class LoginRequest(BaseModel):
    """登录请求"""
    username: str
    password: str

class ShopLinksRequest(BaseModel):
    """更新店铺链接"""
    taobao: str = ""
    jingdong: str = ""
    pinduoduo: str = ""
    douyin: str = ""
    weidian: str = ""
    custom: str = ""

# 默认套餐
DEFAULT_PACKAGES = [
    Package(
        id="free",
        name="免费试用",
        price=0,
        credits=10,
        description="新手体验",
        features=["10次生成额度", "基础文案生成", "有效期7天"]
    ),
    Package(
        id="basic",
        name="基础版",
        price=99,
        credits=100,
        description="个人使用",
        features=["100次生成额度", "全部功能", "有效期30天"]
    ),
    Package(
        id="pro",
        name="专业版",
        price=299,
        credits=500,
        description="商家必备",
        features=["500次生成额度", "全部功能", "专属客服", "有效期90天"]
    ),
    Package(
        id="unlimited",
        name="无限版",
        price=999,
        credits=999999,
        description="企业用户",
        features=["无限次生成", "全部功能", "专属客服", "API接口", "有效期365天"]
    )
]
