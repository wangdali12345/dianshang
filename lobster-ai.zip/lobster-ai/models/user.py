from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

class User(BaseModel):
    """用户模型"""
    id: Optional[int] = None
    phone: str = Field(..., description="手机号")
    password: str = Field("", description="密码(加密存储)")
    nickname: str = Field("", description="昵称")
    created_at: Optional[datetime] = None
    is_active: bool = True

class Package(BaseModel):
    """套餐模型"""
    id: str = Field(..., description="套餐ID")
    name: str = Field(..., description="套餐名称")
    price: float = Field(..., description="价格(元)")
    credits: int = Field(..., description="额度/次数")
    description: str = Field("", description="套餐描述")
    features: list = Field(default_factory=list, description="功能列表")

class UserSubscription(BaseModel):
    """用户订阅"""
    id: Optional[int] = None
    user_id: int
    package_id: str
    credits_remaining: int
    start_date: datetime
    end_date: datetime
    is_active: bool = True

class LoginRequest(BaseModel):
    """登录请求"""
    phone: str
    password: str

class RegisterRequest(BaseModel):
    """注册请求"""
    phone: str
    password: str
    verify_code: str

class VerifyCodeRequest(BaseModel):
    """获取验证码"""
    phone: str

# 默认套餐
DEFAULT_PACKAGES = [
    Package(
        id="free",
        name="免费试用",
        price=0,
        credits=5,
        description="新手体验",
        features=["5次生成额度", "基础文案生成", "有效期7天"]
    ),
    Package(
        id="basic",
        name="基础版",
        price=99,
        credits=100,
        description="个人使用",
        features=["100次生成额度", "全部功能", "有效期30天"]
    ),
    Package(
        id="pro",
        name="专业版",
        price=299,
        credits=500,
        description="商家必备",
        features=["500次生成额度", "全部功能", "专属客服", "有效期90天"]
    ),
    Package(
        id="unlimited",
        name="无限版",
        price=999,
        credits=999999,
        description="企业用户",
        features=["无限次生成", "全部功能", "专属客服", "API接口", "有效期365天"]
    )
]
