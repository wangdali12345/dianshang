from pydantic import BaseModel, Field
from typing import Optional

class ProductInput(BaseModel):
    """商品输入参数"""
    product_name: str = Field(..., description="商品名称")
    category: str = Field(..., description="商品类目")
    features: str = Field("", description="商品特点/卖点")
    style: str = Field("电商白底图", description="图片风格")
    scene: str = Field("现代简约风格", description="场景风格")

class ProductResult(BaseModel):
    """商品生成结果"""
    titles: str = Field(..., description="生成的标题列表")
    description: str = Field(..., description="生成的商品描述")
    main_image_url: str = Field(..., description="商品主图URL")
    scene_image_url: str = Field(..., description="商品场景图URL")

class TitleRequest(BaseModel):
    """标题生成请求"""
    product_name: str
    category: str

class DescRequest(BaseModel):
    """描述生成请求"""
    product_name: str
    features: str
    category: str

class ImageRequest(BaseModel):
    """图片生成请求"""
    product_name: str
    style: str = "电商白底图"
    scene: str = "现代简约风格"

class HealthResponse(BaseModel):
    """健康检查响应"""
    status: str
    service: str
    version: str
