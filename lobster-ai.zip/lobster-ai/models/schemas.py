from pydantic import BaseModel, Field
from typing import Optional

class ProductInput(BaseModel):
    """商品输入参数"""
    product_name: str = Field(..., description="商品名称")
    category: str = Field(..., description="商品类目")
    features: str = Field("", description="商品特点/卖点")
    style: str = Field("电商白底图", description="图片风格")
    scene: str = Field("现代简约风格", description="场景风格")
    reference_image: Optional[str] = Field(None, description="参考图片URL")

class ProductResult(BaseModel):
    """商品生成结果"""
    titles: str = Field(..., description="生成的标题列表")
    description: str = Field(..., description="生成的商品描述")
    main_image_url: str = Field(..., description="商品主图URL")
    scene_image_url: str = Field(..., description="商品场景图URL")

class PosterRequest(BaseModel):
    """海报生成请求"""
    product_name: str = Field(..., description="商品名称")
    main_title: str = Field(..., description="海报主标题")
    sub_title: str = Field("限时特惠", description="海报副标题")
    price_text: str = Field(..., description="价格/促销语")
    style: str = Field("现代简约", description="海报风格")

class TitleRequest(BaseModel):
    """标题生成请求"""
    product_name: str
    category: str

class DescRequest(BaseModel):
    """描述生成请求"""
    product_name: str
    features: str
    category: str

class ImageRequest(BaseModel):
    """图片生成请求"""
    product_name: str
    style: str = "电商白底图"
    scene: str = "现代简约风格"
    reference_image: Optional[str] = None

class HealthResponse(BaseModel):
    """健康检查响应"""
    status: str
    service: str
    version: str
