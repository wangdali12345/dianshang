from fastapi import HTTPException, Security
from fastapi.security import APIKeyHeader
from typing import Optional
import os

# API Key 认证（生产环境使用）
# 通过环境变量配置，允许多个 Key，用逗号分隔
ALLOWED_API_KEYS = os.getenv("ALLOWED_API_KEYS", "").split(",") if os.getenv("ALLOWED_API_KEYS") else []
API_KEY_NAME = "X-API-Key"

api_key_header = APIKeyHeader(name=API_KEY_NAME, auto_error=False)


async def verify_api_key(api_key: Optional[str] = Security(api_key_header)) -> str:
    """
    验证 API Key
    如果未配置 ALLOWED_API_KEYS，则跳过验证（开发模式）
    """
    if not ALLOWED_API_KEYS or ALLOWED_API_KEYS == [""]:
        # 未配置 API Key，开发模式
        return "dev-mode"

    if api_key is None:
        raise HTTPException(
            status_code=401,
            detail="缺少 API Key，请通过 X-API-Key header 传递"
        )

    if api_key not in ALLOWED_API_KEYS:
        raise HTTPException(
            status_code=403,
            detail="无效的 API Key"
        )

    return api_key
