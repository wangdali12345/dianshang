from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from services.auth_service import register_user, login_user, get_user_info, deduct_credit, add_credits
from models.user import DEFAULT_PACKAGES

router = APIRouter(prefix="/api/v1/auth")

class RegisterRequest(BaseModel):
    username: str
    password: str

class LoginRequest(BaseModel):
    username: str
    password: str

@router.post("/register")
async def register(item: RegisterRequest):
    """用户注册"""
    if len(item.password) < 6:
        raise HTTPException(status_code=400, detail="密码至少6位")

    result = register_user(item.username, item.password)
    if not result["success"]:
        raise HTTPException(status_code=400, detail=result["message"])

    return {
        "success": True,
        "data": {
            "user_id": result["user_id"],
            "username": result["username"],
            "api_key": result["api_key"],
            "credits": result["credits"]
        }
    }

@router.post("/login")
async def login(item: LoginRequest):
    """用户登录"""
    result = login_user(item.username, item.password)
    if not result["success"]:
        raise HTTPException(status_code=401, detail=result["message"])

    return {
        "success": True,
        "data": {
            "user_id": result["user_id"],
            "username": result["username"],
            "nickname": result["nickname"],
            "api_key": result["api_key"],
            "credits": result["credits"]
        }
    }

@router.get("/user/{user_id}")
async def get_user(user_id: int):
    """获取用户信息"""
    user = get_user_info(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="用户不存在")
    return {"success": True, "data": user}

@router.get("/packages")
async def get_packages():
    """获取套餐列表"""
    return {
        "success": True,
        "data": [pkg.dict() for pkg in DEFAULT_PACKAGES]
    }

@router.post("/purchase")
async def purchase(package_id: str, user_id: int):
    """购买套餐"""
    pkg = next((p for p in DEFAULT_PACKAGES if p.id == package_id), None)
    if not pkg:
        raise HTTPException(status_code=404, detail="套餐不存在")

    # 实际应接入支付，这里直接开通
    add_credits(user_id, pkg.credits)

    return {
        "success": True,
        "message": f"购买成功！已获得 {pkg.credits} 次额度",
        "credits": pkg.credits
    }
