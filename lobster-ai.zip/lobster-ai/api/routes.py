from fastapi import APIRouter, HTTPException, Depends
from models.schemas import (
    ProductInput,
    ProductResult,
    TitleRequest,
    DescRequest,
    ImageRequest,
    PosterRequest,
)
from services.text_service import TextService
from services.image_service import ImageService
from utils.config import Config
import asyncio

router = APIRouter(prefix="/api/v1")

# 初始化服务
text_service = TextService(
    provider=Config.TEXT_PROVIDER,
    api_key=Config.get_text_api_key()
)
image_service = ImageService(
    provider=Config.IMAGE_PROVIDER,
    api_key=Config.get_image_api_key()
)


@router.post("/generate/product", response_model=ProductResult)
async def generate_product(item: ProductInput):
    """一键生成商品文案 + 效果图"""
    try:
        results = await asyncio.gather(
            text_service.generate_titles(item.product_name, item.category),
            text_service.generate_description(
                item.product_name, item.features, item.category
            ),
            image_service.generate_main_image(item.product_name, item.style, item.reference_image),
            image_service.generate_scene_image(item.product_name, item.scene, item.reference_image),
        )

        titles, description, main_image, scene_image = results

        return ProductResult(
            titles=titles,
            description=description,
            main_image_url=main_image,
            scene_image_url=scene_image,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/generate/poster")
async def generate_poster(item: PosterRequest):
    """生成带文字的电商海报"""
    try:
        poster_url = await image_service.generate_poster(
            item.product_name,
            item.main_title,
            item.sub_title,
            item.price_text,
            item.style
        )
        return {"success": True, "data": {"poster_url": poster_url}, "provider": Config.IMAGE_PROVIDER}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/generate/titles")
async def generate_titles(item: TitleRequest):
    """仅生成商品标题"""
    try:
        titles = await text_service.generate_titles(
            item.product_name, item.category
        )
        return {"success": True, "data": titles, "provider": Config.TEXT_PROVIDER}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/generate/description")
async def generate_description(item: DescRequest):
    """仅生成商品描述"""
    try:
        description = await text_service.generate_description(
            item.product_name, item.features, item.category
        )
        return {"success": True, "data": description, "provider": Config.TEXT_PROVIDER}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/generate/main-image")
async def generate_main_image(item: ImageRequest):
    """仅生成商品主图"""
    try:
        image_url = await image_service.generate_main_image(
            item.product_name, item.style, item.reference_image
        )
        return {"success": True, "data": {"image_url": image_url}, "provider": Config.IMAGE_PROVIDER}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/generate/scene-image")
async def generate_scene_image(item: ImageRequest):
    """仅生成商品场景图"""
    try:
        image_url = await image_service.generate_scene_image(
            item.product_name, item.scene, item.reference_image
        )
        return {"success": True, "data": {"image_url": image_url}, "provider": Config.IMAGE_PROVIDER}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/providers")
async def get_providers():
    """获取当前配置的 AI Provider"""
    return {
        "text_provider": Config.TEXT_PROVIDER,
        "image_provider": Config.IMAGE_PROVIDER,
        "available_text_providers": ["claude", "zhipu", "minimax"],
        "available_image_providers": ["openai", "zhipu", "minimax"]
    }
