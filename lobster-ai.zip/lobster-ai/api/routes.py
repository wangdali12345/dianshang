from fastapi import APIRouter, HTTPException, Depends
from models.schemas import (
    ProductInput,
    ProductResult,
    TitleRequest,
    DescRequest,
    ImageRequest,
)
from services.text_service import TextService
from services.image_service import ImageService
from utils.config import Config
from api.auth import verify_api_key
import asyncio
import logging

logger = logging.getLogger("lobster-ai")

router = APIRouter(prefix="/api/v1")

# 初始化服务（根据配置选择 provider）
text_service = TextService(
    provider=Config.TEXT_PROVIDER,
    api_key=Config.get_text_api_key()
)
image_service = ImageService(
    provider=Config.IMAGE_PROVIDER,
    api_key=Config.get_image_api_key()
)


@router.post("/generate/product", response_model=ProductResult)
async def generate_product(item: ProductInput, api_key: str = Depends(verify_api_key)):
    """一键生成商品文案 + 效果图"""
    logger.info(f"生成商品: {item.product_name}, API Key: {api_key}")
    try:
        # 并行执行文案 + 图片生成
        results = await asyncio.gather(
            text_service.generate_titles(item.product_name, item.category),
            text_service.generate_description(
                item.product_name, item.features, item.category
            ),
            image_service.generate_main_image(item.product_name, item.style),
            image_service.generate_scene_image(item.product_name, item.scene),
        )

        titles, description, main_image, scene_image = results
        logger.info(f"商品生成成功: {item.product_name}")

        return ProductResult(
            titles=titles,
            description=description,
            main_image_url=main_image,
            scene_image_url=scene_image,
        )
    except Exception as e:
        logger.error(f"商品生成失败: {item.product_name}, Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/generate/titles")
async def generate_titles(item: TitleRequest, api_key: str = Depends(verify_api_key)):
    """仅生成商品标题"""
    try:
        titles = await text_service.generate_titles(
            item.product_name, item.category
        )
        return {"success": True, "data": titles, "provider": Config.TEXT_PROVIDER}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/generate/description")
async def generate_description(item: DescRequest, api_key: str = Depends(verify_api_key)):
    """仅生成商品描述"""
    try:
        description = await text_service.generate_description(
            item.product_name, item.features, item.category
        )
        return {"success": True, "data": description, "provider": Config.TEXT_PROVIDER}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/generate/main-image")
async def generate_main_image(item: ImageRequest, api_key: str = Depends(verify_api_key)):
    """仅生成商品主图"""
    try:
        image_url = await image_service.generate_main_image(
            item.product_name, item.style
        )
        return {"success": True, "data": {"image_url": image_url}, "provider": Config.IMAGE_PROVIDER}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/generate/scene-image")
async def generate_scene_image(item: ImageRequest, api_key: str = Depends(verify_api_key)):
    """仅生成商品场景图"""
    try:
        image_url = await image_service.generate_scene_image(
            item.product_name, item.scene
        )
        return {"success": True, "data": {"image_url": image_url}, "provider": Config.IMAGE_PROVIDER}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/providers")
async def get_providers():
    """获取当前配置的 AI Provider"""
    return {
        "text_provider": Config.TEXT_PROVIDER,
        "image_provider": Config.IMAGE_PROVIDER,
        "available_text_providers": ["claude", "zhipu", "minimax"],
        "available_image_providers": ["openai", "zhipu", "minimax"]
    }
