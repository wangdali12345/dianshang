# 龙虾AI电商平台

AI 驱动的电商商品文案和图片生成平台

## 功能

- 一键生成商品标题（5个不同风格）
- AI 生成专业商品详情描述
- AI 生成商品主图（智谱 CogView）
- AI 生成商品场景图
- 支持多 AI Provider 切换

## 支持的 AI Provider

### 文本生成
| Provider | 模型 | 说明 |
|---|---|---|
| **智谱 GLM** | glm-4-flash | ✅ 已配置 |
| **Claude** | claude-sonnet | 可选 |
| **MiniMax** | abab6.5s-chat | 可选 |

### 图片生成
| Provider | 模型 | 说明 |
|---|---|---|
| **智谱 CogView** | cogview-3 | ✅ 已配置 |
| **OpenAI** | DALL-E 3 | 可选 |
| **MiniMax** | Image-01 | 可选 |

## 快速开始

### 1. 安装依赖

```bash
pip install -r requirements.txt
```

### 2. 配置环境变量

```bash
cp .env.example .env
# 编辑 .env 填入 API Key
```

### 3. 启动服务

```bash
python main.py
```

或

```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

### 4. 访问文档

- API 文档：http://localhost:8000/docs
- 健康检查：http://localhost:8000/health

## Docker 部署

```bash
# 构建镜像
docker build -t lobster-ai .

# 运行容器
docker run -d -p 8000:8000 \
  -e ZHIPU_API_KEY=your_api_key \
  --name lobster-ai \
  lobster-ai
```

或使用 docker-compose：

```bash
ZHIPU_API_KEY=your_api_key docker-compose up -d
```

## API 接口

### 一键生成商品

```bash
POST /api/v1/generate/product
Content-Type: application/json
X-API-Key: your_api_key  # 生产环境必填

{
  "product_name": "鲜活波士顿龙虾",
  "category": "海鲜水产",
  "features": "鲜活空运、冷链配送、保证存活",
  "style": "电商白底图",
  "scene": "高档餐厅餐桌"
}
```

### 单独生成标题

```bash
POST /api/v1/generate/titles
```

### 单独生成描述

```bash
POST /api/v1/generate/description
```

### 单独生成主图

```bash
POST /api/v1/generate/main-image
```

### 单独生成场景图

```bash
POST /api/v1/generate/scene-image
```

### 查看当前 Provider

```bash
GET /api/v1/providers
```

## 生产环境配置

```env
# 必填
TEXT_PROVIDER=zhipu
IMAGE_PROVIDER=zhipu
ZHIPU_API_KEY=your_api_key

# API 认证（多个 Key 用逗号分隔）
ALLOWED_API_KEYS=key1,key2,key3

# 日志
LOG_LEVEL=INFO
```

## 项目结构

```
lobster-ai/
├── main.py              # FastAPI 入口
├── requirements.txt     # 依赖
├── .env.example         # 配置示例
├── Dockerfile           # Docker 配置
├── docker-compose.yml   # Docker Compose 配置
│
├── api/
│   ├── routes.py        # API 路由
│   └── auth.py          # API 认证
│
├── services/
│   ├── text_service.py  # 文本生成服务
│   └── image_service.py # 图片生成服务
│
├── prompts/
│   ├── product_title.py # 标题提示词
│   ├── product_desc.py # 描述提示词
│   └── product_image.py # 图片提示词
│
├── models/
│   └── schemas.py       # 数据模型
│
└── utils/
    ├── config.py        # 配置管理
    └── logging_config.py # 日志配置
```

## 技术栈

- **FastAPI** - Web 框架
- **Pydantic** - 数据验证
- **Uvicorn** - ASGI 服务器
- **智谱 AI** - 文本+图片生成
- **Docker** - 容器化部署
