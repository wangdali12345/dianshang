import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import openai
from zhipuai import ZhipuAI

IMAGE_PROMPT = "{product_name}，风格：{style}，要求：专业电商海报设计，画面设计感强，商业摄影风格，产品展示清晰，整体色调专业，适合电商平台"

SCENE_PROMPT = "{product_name}，场景：{scene}，要求：真实生活场景，产品融入场景，自然光线，画面温馨有质感，适合作为详情页场景图"

POSTER_PROMPT = "{product_name}，海报主标题：{main_title}，副标题：{sub_title}，促销语：{price_text}，风格：{style}，要求：专业电商促销海报设计，文字醒目，位置合理（画面中心或底部），淘宝/天猫促销海报风格，整体设计感强"

POSTER_WITH_REF_PROMPT = "{product_name}，海报主标题：{main_title}，副标题：{sub_title}，促销语：{price_text}，风格：{style}，参考图风格：{reference_note}，要求：专业电商促销海报设计，文字醒目，位置合理（画面中心或底部），淘宝/天猫促销海报风格，整体设计感强"

class ImageService:
    def __init__(self, provider: str, api_key: str):
        self.provider = provider
        if provider == "openai":
            self.client = openai.OpenAI(api_key=api_key)
        elif provider == "zhipu":
            self.client = ZhipuAI(api_key=api_key)

    async def generate_main_image(self, product_name: str, style: str = "电商白底图", reference_image: str = None) -> str:
        prompt = IMAGE_PROMPT.format(product_name=product_name, style=style)
        if reference_image:
            prompt = f"参考图片的风格：{prompt}"
        return await self._generate_image(prompt)

    async def generate_scene_image(self, product_name: str, scene: str = "现代简约风格", reference_image: str = None) -> str:
        prompt = SCENE_PROMPT.format(product_name=product_name, scene=scene)
        if reference_image:
            prompt = f"参考图片的风格：{prompt}"
        return await self._generate_image(prompt)

    async def generate_poster(self, product_name: str, main_title: str, sub_title: str, price_text: str, style: str = "现代简约", reference_image: str = None) -> str:
        if reference_image:
            prompt = POSTER_WITH_REF_PROMPT.format(
                product_name=product_name,
                main_title=main_title,
                sub_title=sub_title,
                price_text=price_text,
                style=style,
                reference_note="参考上传图片的整体色调、光线、构图风格"
            )
        else:
            prompt = POSTER_PROMPT.format(
                product_name=product_name,
                main_title=main_title,
                sub_title=sub_title,
                price_text=price_text,
                style=style
            )
        return await self._generate_image(prompt)

    async def _generate_image(self, prompt: str) -> str:
        if self.provider == "openai":
            response = self.client.images.generate(model="dall-e-3", prompt=prompt, size="1024x1024", quality="standard", n=1)
            return response.data[0].url
        elif self.provider == "zhipu":
            response = self.client.images.generations(model="cogview-3", prompt=prompt)
            return response.data[0].url
        raise ValueError(f"Unknown provider: {self.provider}")
