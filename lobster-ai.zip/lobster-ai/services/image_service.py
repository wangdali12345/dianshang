import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import openai
import httpx
from zhipuai import ZhipuAI
from prompts.product_image import IMAGE_PROMPT, SCENE_PROMPT, POSTER_PROMPT


class ImageService:
    """图片生成服务 - 支持 OpenAI DALL-E 和 智谱 CogView"""

    def __init__(self, provider: str, api_key: str):
        """
        初始化图片服务
        provider: "openai" | "zhipu"
        """
        self.provider = provider
        self.api_key = api_key

        if provider == "openai":
            self.client = openai.OpenAI(api_key=api_key)
        elif provider == "zhipu":
            self.client = ZhipuAI(api_key=api_key)

    async def generate_main_image(
        self, product_name: str, style: str = "电商白底图", reference_image: str = None
    ) -> str:
        """生成商品主图"""
        prompt = IMAGE_PROMPT.format(
            product_name=product_name,
            style=style
        )
        return await self._generate_image(prompt, reference_image)

    async def generate_scene_image(
        self, product_name: str, scene: str = "现代简约风格", reference_image: str = None
    ) -> str:
        """生成商品场景图"""
        prompt = SCENE_PROMPT.format(
            product_name=product_name,
            scene=scene
        )
        return await self._generate_image(prompt, reference_image)

    async def generate_poster(
        self, product_name: str, main_title: str, sub_title: str, price_text: str, style: str = "现代简约"
    ) -> str:
        """生成带文字的海报图"""
        prompt = POSTER_PROMPT.format(
            product_name=product_name,
            main_title=main_title,
            sub_title=sub_title,
            price_text=price_text,
            style=style
        )
        return await self._generate_image(prompt)

    async def _generate_image(self, prompt: str, reference_image: str = None) -> str:
        """根据 provider 生成图片"""
        if self.provider == "openai":
            response = self.client.images.generate(
                model="dall-e-3",
                prompt=prompt,
                size="1024x1024",
                quality="standard",
                n=1
            )
            return response.data[0].url

        elif self.provider == "zhipu":
            # 智谱 CogView 不支持 reference_image 参数，需要根据是否有参考图选择不同提示词
            if reference_image:
                prompt = f"参考这张图片的风格：{prompt}\n[参考图:{reference_image}]"

            response = self.client.images.generations(
                model="cogview-3",
                prompt=prompt
            )
            return response.data[0].url

        raise ValueError(f"Unknown provider: {self.provider}")
