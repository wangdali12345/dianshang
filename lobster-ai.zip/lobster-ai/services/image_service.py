import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import openai
from zhipuai import ZhipuAI

IMAGE_PROMPT = "电商海报设计图，{product_name}，风格：{style}，要求：1. 海报整体设计感强，商业摄影风格 2. 画面中间或底部留出文字区域 3. 文字区域位置清晰可见 4. 产品展示清晰，突出卖点 5. 整体色调专业，适合电商平台 6. 不要在图片上写任何文字，但留出文字位置"

SCENE_PROMPT = "电商场景展示图，{product_name}，场景：{scene}，要求：1. 真实生活场景，产品融入场景 2. 自然光线，画面温馨有质感 3. 适合作为详情页场景图 4. 画面整洁，有留白区域 5. 不要在图片上写任何文字"

POSTER_PROMPT = "电商促销海报设计图，{product_name}，风格：{style}，要求：1. 专业电商海报设计 2. 画面设计感强，商业摄影与设计结合 3. 必须包含以下文字内容（直接写在图片上）：主标题：{main_title}，副标题：{sub_title}，价格或促销语：{price_text}，4. 文字要醒目，位置合理（通常在画面中心或底部），5. 产品图片清晰，促销信息突出，6. 整体风格：淘宝/京东/天猫促销海报风格"

class ImageService:
    def __init__(self, provider: str, api_key: str):
        self.provider = provider
        if provider == "openai":
            self.client = openai.OpenAI(api_key=api_key)
        elif provider == "zhipu":
            self.client = ZhipuAI(api_key=api_key)

    async def generate_main_image(self, product_name: str, style: str = "电商白底图", reference_image: str = None) -> str:
        prompt = IMAGE_PROMPT.format(product_name=product_name, style=style)
        return await self._generate_image(prompt, reference_image)

    async def generate_scene_image(self, product_name: str, scene: str = "现代简约风格", reference_image: str = None) -> str:
        prompt = SCENE_PROMPT.format(product_name=product_name, scene=scene)
        return await self._generate_image(prompt, reference_image)

    async def generate_poster(self, product_name: str, main_title: str, sub_title: str, price_text: str, style: str = "现代简约") -> str:
        prompt = POSTER_PROMPT.format(product_name=product_name, main_title=main_title, sub_title=sub_title, price_text=price_text, style=style)
        return await self._generate_image(prompt)

    async def _generate_image(self, prompt: str, reference_image: str = None) -> str:
        if self.provider == "openai":
            response = self.client.images.generate(model="dall-e-3", prompt=prompt, size="1024x1024", quality="standard", n=1)
            return response.data[0].url
        elif self.provider == "zhipu":
            if reference_image:
                prompt = f"参考这张图片的风格：{prompt}\n[参考图:{reference_image}]"
            response = self.client.images.generations(model="cogview-3", prompt=prompt)
            return response.data[0].url
        raise ValueError(f"Unknown provider: {self.provider}")
