import sqlite3
import hashlib
import uuid
from pathlib import Path
from datetime import datetime
import json

DB_PATH = Path(__file__).parent.parent / "data" / "users.db"

def init_db():
    """初始化数据库"""
    DB_PATH.parent.mkdir(exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            nickname TEXT DEFAULT '',
            api_key TEXT DEFAULT '',
            credits INTEGER DEFAULT 0,
            shop_links TEXT DEFAULT '{}',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            is_active INTEGER DEFAULT 1
        )
    """)
    conn.commit()
    conn.close()

def hash_password(password: str) -> str:
    """密码哈希"""
    return hashlib.sha256(password.encode()).hexdigest()

def generate_api_key() -> str:
    """生成API Key"""
    return f"lobster_{uuid.uuid4().hex}{uuid.uuid4().hex[:8]}"

def register_user(username: str, password: str) -> dict:
    """注册用户"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    c.execute("SELECT id FROM users WHERE username = ?", (username,))
    if c.fetchone():
        conn.close()
        return {"success": False, "message": "该用户名已注册"}

    api_key = generate_api_key()
    credits = 10  # 新用户送10次体验
    shop_links = json.dumps({"taobao":"","jingdong":"","pinduoduo":"","douyin":"","weidian":"","custom":""})

    c.execute("""
        INSERT INTO users (username, password, nickname, api_key, credits, shop_links)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (username, hash_password(password), username, api_key, credits, shop_links))

    user_id = c.lastrowid
    conn.commit()
    conn.close()

    return {"success": True, "user_id": user_id, "username": username, "api_key": api_key, "credits": credits}

def login_user(username: str, password: str) -> dict:
    """用户登录"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        SELECT id, username, nickname, api_key, credits, shop_links FROM users
        WHERE username = ? AND password = ? AND is_active = 1
    """, (username, hash_password(password)))
    result = c.fetchone()
    conn.close()

    if not result:
        return {"success": False, "message": "用户名或密码错误"}

    return {
        "success": True,
        "user_id": result[0],
        "username": result[1],
        "nickname": result[2],
        "api_key": result[3],
        "credits": result[4],
        "shop_links": json.loads(result[5]) if result[5] else {}
    }

def get_user_info(user_id: int) -> dict:
    """获取用户信息"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        SELECT id, username, nickname, api_key, credits, shop_links, created_at FROM users WHERE id = ?
    """, (user_id,))
    result = c.fetchone()
    conn.close()

    if not result:
        return None

    return {
        "user_id": result[0],
        "username": result[1],
        "nickname": result[2],
        "api_key": result[3],
        "credits": result[4],
        "shop_links": json.loads(result[5]) if result[5] else {},
        "created_at": result[6]
    }

def update_shop_links(user_id: int, shop_links: dict) -> bool:
    """更新店铺链接"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("UPDATE users SET shop_links = ? WHERE id = ?", (json.dumps(shop_links), user_id))
    conn.commit()
    conn.close()
    return True

def deduct_credit(user_id: int) -> bool:
    """扣减额度"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT credits FROM users WHERE id = ?", (user_id,))
    result = c.fetchone()
    if not result or result[0] <= 0:
        conn.close()
        return False
    c.execute("UPDATE users SET credits = credits - 1 WHERE id = ?", (user_id,))
    conn.commit()
    conn.close()
    return True

def add_credits(user_id: int, amount: int):
    """增加额度"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("UPDATE users SET credits = credits + ? WHERE id = ?", (amount, user_id))
    conn.commit()
    conn.close()

# 初始化数据库
init_db()
