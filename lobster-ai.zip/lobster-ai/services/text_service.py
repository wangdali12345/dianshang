import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import anthropic
import httpx
from zhipuai import ZhipuAI
from prompts.product_title import TITLE_PROMPT
from prompts.product_desc import DESC_PROMPT


class TextService:
    """文案生成服务 - 支持多平台"""

    def __init__(self, provider: str, api_key: str):
        """
        初始化文案服务
        provider: "claude" | "zhipu" | "minimax"
        """
        self.provider = provider
        self.api_key = api_key

        if provider == "claude":
            self.client = anthropic.Anthropic(api_key=api_key)
        elif provider == "zhipu":
            self.client = ZhipuAI(api_key=api_key)
        elif provider == "minimax":
            self.http_client = httpx.AsyncClient(
                base_url="https://api.minimax.chat/v1",
                headers={"Authorization": f"Bearer {api_key}"},
                timeout=60.0
            )

    async def generate_titles(self, product_name: str, category: str) -> str:
        """生成商品标题"""
        prompt = TITLE_PROMPT.format(
            product_name=product_name,
            category=category
        )

        if self.provider == "claude":
            response = self.client.messages.create(
                model="claude-sonnet-4-20250514",
                max_tokens=1024,
                messages=[{"role": "user", "content": prompt}]
            )
            return response.content[0].text

        elif self.provider == "zhipu":
            response = self.client.chat.completions.create(
                model="glm-4-flash",
                messages=[{"role": "user", "content": prompt}]
            )
            return response.choices[0].message.content

        elif self.provider == "minimax":
            response = await self.http_client.post(
                "/text/chatcompletion_v2",
                json={
                    "model": "abab6.5s-chat",
                    "messages": [{"role": "user", "content": prompt}]
                }
            )
            data = response.json()
            return data["choices"][0]["message"]["content"]

        raise ValueError(f"Unknown provider: {self.provider}")

    async def generate_description(
        self, product_name: str, features: str, category: str
    ) -> str:
        """生成商品描述"""
        prompt = DESC_PROMPT.format(
            product_name=product_name,
            features=features,
            category=category
        )

        if self.provider == "claude":
            response = self.client.messages.create(
                model="claude-sonnet-4-20250514",
                max_tokens=2048,
                messages=[{"role": "user", "content": prompt}]
            )
            return response.content[0].text

        elif self.provider == "zhipu":
            response = self.client.chat.completions.create(
                model="glm-4-flash",
                messages=[{"role": "user", "content": prompt}]
            )
            return response.choices[0].message.content

        elif self.provider == "minimax":
            response = await self.http_client.post(
                "/text/chatcompletion_v2",
                json={
                    "model": "abab6.5s-chat",
                    "messages": [{"role": "user", "content": prompt}]
                }
            )
            data = response.json()
            return data["choices"][0]["message"]["content"]

        raise ValueError(f"Unknown provider: {self.provider}")
