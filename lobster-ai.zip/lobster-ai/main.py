import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from api.routes import router
from utils.config import Config
from utils.logging_config import setup_logging

# 初始化日志
logger = setup_logging()

app = FastAPI(
    title="龙虾AI电商平台",
    description="AI 驱动的电商商品文案和图片生成平台",
    version=Config.VERSION,
)

# CORS 配置
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 挂载路由
app.include_router(router)


@app.on_event("startup")
async def startup_event():
    logger.info(f"龙虾AI电商平台启动成功")
    logger.info(f"文本 Provider: {Config.TEXT_PROVIDER}")
    logger.info(f"图片 Provider: {Config.IMAGE_PROVIDER}")


@app.get("/")
async def root():
    return {
        "service": Config.SERVICE_NAME,
        "version": Config.VERSION,
        "docs": "/docs",
    }


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "service": Config.SERVICE_NAME,
        "version": Config.VERSION,
    }


if __name__ == "__main__":
    logger.info(f"启动服务: {Config.HOST}:{Config.PORT}")
    uvicorn.run(
        "main:app",
        host=Config.HOST,
        port=Config.PORT,
        reload=True,
        log_level="info",
    )
