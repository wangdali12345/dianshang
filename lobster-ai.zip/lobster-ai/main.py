import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from api.routes import router
from utils.config import Config
import logging
import os

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger("lobster-ai")

app = FastAPI(
    title="龙虾AI电商平台",
    description="AI 驱动的电商商品文案和图片生成平台",
    version=Config.VERSION,
)

# CORS 配置
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 挂载静态文件
static_dir = os.path.join(os.path.dirname(__file__), "static")
if os.path.exists(static_dir):
    app.mount("/static", StaticFiles(directory=static_dir), name="static")

# 根路径返回 index.html
@app.get("/")
async def root():
    index_path = os.path.join(os.path.dirname(__file__), "static", "index.html")
    if os.path.exists(index_path):
        return FileResponse(index_path)
    return {"message": "龙虾AI电商平台", "docs": "/docs"}

# 挂载 API 路由
app.include_router(router)


@app.on_event("startup")
async def startup_event():
    logger.info(f"龙虾AI电商平台启动成功")
    logger.info(f"文本 Provider: {Config.TEXT_PROVIDER}")
    logger.info(f"图片 Provider: {Config.IMAGE_PROVIDER}")


@app.get("/health")
async def health():
    return {"status": "ok", "service": Config.SERVICE_NAME, "version": Config.VERSION}


if __name__ == "__main__":
    logger.info(f"启动服务: {Config.HOST}:{Config.PORT}")
    uvicorn.run(
        "main:app",
        host=Config.HOST,
        port=Config.PORT,
        reload=False,
        log_level="info",
    )
