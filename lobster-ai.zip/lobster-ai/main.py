import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from api.routes import router
import logging
import os

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger("lobster-ai")

app = FastAPI(
    title="龙虾AI电商平台",
    description="AI 驱动的电商商品文案和图片生成平台",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

static_dir = os.path.join(os.path.dirname(__file__), "static")
if os.path.exists(static_dir):
    app.mount("/static", StaticFiles(directory=static_dir), name="static")

@app.get("/")
async def root():
    index_path = os.path.join(os.path.dirname(__file__), "static", "index.html")
    if os.path.exists(index_path):
        return FileResponse(index_path)
    return {"message": "龙虾AI电商平台", "docs": "/docs"}

app.include_router(router)

@app.on_event("startup")
async def startup_event():
    logger.info("龙虾AI电商平台启动成功")
    logger.info("文本 Provider: zhipu")
    logger.info("图片 Provider: zhipu")

@app.get("/health")
async def health():
    return {"status": "ok", "service": "lobster-ai", "version": "1.0.0"}

if __name__ == "__main__":
    logger.info("启动服务: 0.0.0.0:8000")
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=False, log_level="info")
